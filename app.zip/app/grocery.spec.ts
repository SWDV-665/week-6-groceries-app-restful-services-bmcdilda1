import { Grocery } from './grocery';

describe('Grocery', () => {
  it('should create an instance', () => {
    expect(new Grocery()).toBeTruthy();
  });
});
